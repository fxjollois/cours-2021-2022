library(shiny)
library(shinydashboard)
library(mongolite)
library(dplyr)
library(ggplot2)

USER = "user"
PASS = "user"
HOST = "cluster0.ougec.mongodb.net"

URI = sprintf("mongodb+srv://%s:%s@%s/", USER, PASS, HOST)

m = mongo(collection = "movies", db = "test", url = URI)

