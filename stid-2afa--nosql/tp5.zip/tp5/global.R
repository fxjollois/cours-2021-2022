library(shiny)
library(shinydashboard)
library(mongolite)

USER = "user"
PASS = "user"
HOST = "cluster0.ougec.mongodb.net"

URI = sprintf("mongodb+srv://%s:%s@%s/", USER, PASS, HOST)

m = mongo(
  collection = "movies", 
  db = "test",
  url = URI)

# Création de variables globales utiles dans l'application
genres = m$distinct("genres")
annees = m$distinct("year")
