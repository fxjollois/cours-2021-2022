
shinyServer(function(input, output, session) {
  
  #----------------#
  # Onglet GENERAL #
  #----------------#
  
  # Remplacer les "??" par le calcul des valeurs à partir d'une requête vers Mongo
  output$nb_films <- renderText({
    "??"
  })
  output$nb_acteurs <- renderText({
    "??"
  })
  output$nb_pays <- renderText({
    "??"
  })
  
  # Remplacer les "head(co2)" par le calcul des valeurs à partir d'une requête Mongo
  #   -> on veut le nom du film, de l'acteur ou du pays AVEC le nombre de films
  #   -> la commande "head(co2)" est présente pour la visualisation du rendu final
  output$top_genres <- renderTable({
    head(faithful, 5)
  })
  output$top_acteurs <- renderTable({
    head(faithful, 5)
  })
  output$top_pays <- renderTable({
    head(faithful, 5)
  })
  
  # Remplacer "plot(co2)" par le graphique réalisé à partir d'une requête Mongo
  #   -> 2 étapes donc : 
  #     1. requête vers Mongo pour récupérer le nombre de films
  #         - si besoin manipulation du résultat dans R
  #     2. création du graphique à partir de cette requête, idéalement avec ggplot
  #   -> la commande 'plot(co2)" est présente pour la visualisation du rendu final
  output$evol_films_annees <- renderPlot({
    plot(co2)
  })
  
  #-----------------#
  # Onglet NOTATION #
  #-----------------#
  
  # Remplacer les "unique()" par les requêtes dans Mongo permettant de récupérer
  #   1. la liste des différents genres présents dans la base
  genres = unique(txhousing$city)
  #   2. la liste des différentes années présentes dans la base
  annees = unique(txhousing$year)
  
  updateSelectInput(session, inputId = "genre", choices = c("Tous", genres))
  updateSelectInput(session, inputId = "annee", choices = c("Toutes", annees))
  
  # Remplacer le code par une requête Monogo ne demandant que les données nécessaires selon les choix de l'utilisateur
  #   -> Le code est présent pour aider à la visualisation du rendu
  donnees_choisies <- reactive({
    donnees = txhousing %>% filter(month <= 3)
    if (input$genre != "Tous") {
      donnees = donnees %>%
        filter(city == input$genre)
    }
    if (input$annee != "Toutes") {
      donnees = donnees %>%
        filter(year == input$annee)
    }
    donnees
  })
  
  # Remplacer les "ggplot(...) + ..." par les graphiques réalisés à partir des données choisies
  #  -> Les graphiques sont présents pour aider à la visualisation du résultat final
  output$dist_notes <- renderPlot({
    ggplot(donnees_choisies(), aes(volume, fill = factor(month))) +
      geom_histogram() +
      facet_wrap(~ month, ncol = 1)
  })
  output$box_notes <- renderPlot({
    ggplot(donnees_choisies(), aes(factor(month), volume, fill = factor(month))) +
      geom_boxplot()
  })
  
  # Remplacer le calcul par celui permettant d'avoir les films ayant les meilleures notes
  #  -> Le tableau ci-dessous est présent pour aider à la visualisation du résultat final
  output$top_imdb <- renderTable({
    donnees = donnees_choisies() %>%
      group_by(month) %>%
      summarise(volume = mean(volume, na.rm = TRUE))
    if (input$top_flop == "TOP") {
      donnees %>%
        arrange(desc(volume)) %>%
        head(input$taille)
    } else {
      donnees %>%
        arrange(volume) %>%
        head(input$taille)
    }
  })
  
  output$top_rotten_viewer <- renderTable({
  })
  
  output$top_rotten_critic <- renderTable({
  })
  
})
