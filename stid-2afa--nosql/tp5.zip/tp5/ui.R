
shinyUI(dashboardPage(
    dashboardHeader(title = "TP5 - début"),
    dashboardSidebar(
        sidebarMenu(
            menuItem("Général", tabName = "general", icon = icon("columns")),
            menuItem("Notation", tabName = "notation", icon = icon("comments"))
        )
    ),
    dashboardBody(
        tabItems(
            tabItem("general",
                    fluidRow(
                        valueBox("??", "Nombre de films", icon = icon("film"), width = 4, color = "teal"),
                        valueBox("??", "Nombre d'acteurs", icon = icon("users"), width = 4, color = "orange"),
                        valueBox("??", "Nombre de pays", icon = icon("globe"), width = 4, color = "olive")
                    ),
                    fluidRow(
                        box(title = "TOP Films", width = 4, "TOP films"),
                        box(title = "TOP Acteurs", width = 4, "TOP acteurs"),
                        box(title = "TOP Pays", width = 4, "TOP pays")
                    ),
                    fluidRow(box(title = "Evolution des sorties de films", width = 12, "Distribution films par année"))
            ),
            tabItem("notation",
                    fluidRow(
                        box(title = "Genre", width = 6, 
                            selectInput(inputId = "genre", label = NULL, choices = c("Tous", genres))
                        ),
                        box(title = "Année", width = 6, 
                            selectInput(inputId = "annee", label = NULL, choices = c("Toutes", annees))
                        )
                    ),
                    fluidRow(
                        box(title = "Notes attribuées", width = 12, 
                            "représentation à faire pour les 3 notes : IMDB, viwer Rotten et critic Rotten")
                    ),
                    fluidRow(
                        box(title = "TOP/FLOP", width = 6, 
                            radioButtons(inputId = "top_flop", label = NULL, choices = c("TOP", "FLOP"), inline = FALSE)
                        ),
                        box(title = "Taille", width = 6, 
                            selectInput(inputId = "taille", label = NULL, choices = c(5, 10, 20))
                        )
                    ),
                    fluidRow(
                        box(title = "IMDB", width = 4, "TOP IMDB"),
                        box(title = "Rotten tomatoes - public", width = 4, "TOP viewer Rotten"),
                        box(title = "Rotten tomatoes - critique", width = 4, "TOP critic Rotten")
                    )
                    
            )
        )
    ),
    title = "TP5 - début", 
    skin = "red"
))
