
shinyUI(dashboardPage(
    dashboardHeader(title = "TP5"),
    dashboardSidebar(
        sidebarMenu(
            menuItem("Général", tabName = "general", icon = icon("columns")),
            menuItem("Notation", tabName = "notation", icon = icon("comments"))
        )
    ),
    dashboardBody(
        tabItems(
            tabItem("general",
                    fluidRow(
                        valueBox(textOutput("nb_films"), 
                                 "Nombre de films", icon = icon("film"), width = 4, color = "teal"),
                        valueBox(textOutput("nb_acteurs"), 
                                 "Nombre d'acteurs", icon = icon("users"), width = 4, color = "orange"),
                        valueBox(textOutput("nb_pays"), 
                                 "Nombre de pays", icon = icon("globe"), width = 4, color = "olive")
                    ),
                    fluidRow(
                        box(title = "TOP Genres", width = 4, tableOutput("top_genres")),
                        box(title = "TOP Acteurs", width = 4, tableOutput("top_acteurs")),
                        box(title = "TOP Pays", width = 4, tableOutput("top_pays"))
                    ),
                    fluidRow(box(title = "Evolution des sorties de films", width = 12, 
                                 plotOutput("evol_films_annees")))
            ),
            tabItem("notation",
                    fluidRow(
                        box(title = "Genre", width = 6, 
                            selectInput(inputId = "genre", label = NULL, choices = NULL)
                        ),
                        box(title = "Année", width = 6, 
                            selectInput(inputId = "annee", label = NULL, choices = NULL)
                        )
                    ),
                    fluidRow(
                        box(title = "Notes attribuées", width = 12, 
                            column(plotOutput("dist_notes"), width = 7),
                            column(plotOutput("box_notes"), width = 5))
                    ),
                    fluidRow(
                        box(title = "TOP/FLOP", width = 6, 
                            radioButtons(inputId = "top_flop", label = NULL, choices = c("TOP", "FLOP"))
                        ),
                        box(title = "Taille", width = 6, 
                            selectInput(inputId = "taille", label = NULL, choices = c(5, 10, 20))
                        )
                    ),
                    fluidRow(
                        box(title = "IMDB", width = 4, tableOutput("top_imdb")),
                        box(title = "Rotten tomatoes - public", width = 4, tableOutput("top_rotten_viewer")),
                        box(title = "Rotten tomatoes - critique", width = 4, tableOutput("top_rotten_critic"))
                    )
                    
            )
        )
    ),
    title = "TP5", 
    skin = "red"
))
